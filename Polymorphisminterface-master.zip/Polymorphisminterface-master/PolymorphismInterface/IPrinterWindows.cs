﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PolymorphismInterface
{
    interface IPrinterWindows
    {
        void Show();
        void Print();
    }
}
